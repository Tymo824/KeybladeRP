Keyblade Resource Pack for Minecraft Java 26.3

Install this ZIP as a resource pack on each client, or configure it as your server resource pack. Pair with KeybladeDatapack_26.3.zip.

The model is selected using custom_model_data float value 133456.0.
